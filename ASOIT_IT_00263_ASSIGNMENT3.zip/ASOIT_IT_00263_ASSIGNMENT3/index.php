<?php
if (isset($_POST['submit'])) {
    $TxtFirstname = $_POST['TxtFirstname'];
    $TxtLastname = $_POST['TxtLastname'];
    $TxtEmailid = $_POST['TxtEmailid'];
    $city = $_POST['city'];
    $feedback = $_POST['feedback'];

    $host = 'localhost';
    $user = 'root';
    $pass = '';
    $dbname = 'asoit_it_00263_assignment3';

    $conn = mysqli_connect($host, $user, $pass, $dbname);

    $sql = "INSERT INTO student(TxtFirstname,TxtLastname,TxtEmailid,city,feedback) values('$TxtFirstname','$TxtLastname','$TxtEmailid','$city','$feedback')";
    mysqli_query($conn, $sql);
}
?>


<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        * {
            box-sizing: border-box;
        }

        input[type=text],
        select,
        textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid rgb(38, 36, 36);
            border-radius: 4px;
            resize: vertical;
        }

        .head4 {
            text-align: center;
            background: rgb(0, 14, 255);
            background: linear-gradient(73deg, rgba(0, 14, 255, 1) 0%, rgba(8, 0, 255, 1) 23%, rgba(139, 24, 106, 1) 47%, rgba(136, 16, 40, 1) 70%, rgba(135, 12, 12, 1) 100%, rgba(0, 9, 255, 1) 100%);
            color: white;
            font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;
            height: 29px;
            font-size: 24px;
            border-top-left-radius: 7px;
            border-top-right-radius: 7px;
            width: 100%;
        }

        input[type=email],
        select,
        textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid rgb(70, 68, 68);
            border-radius: 4px;
            resize: vertical;
        }

        label {
            padding: 12px 12px 12px 0;
            display: inline-block;
        }

        input[type=submit] {
            background: linear-gradient(90deg, rgba(255, 0, 0, 1) 0%, rgba(255, 0, 0, 1) 29%, rgba(0, 18, 255, 1) 100%);
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            float: right;
        }

        input[type=submit]:hover {
            background-color: #45a049;
        }

        .container {
            margin-top: 10px;
            border-radius: 5px;
            background-color: #ffffff;
            padding: 20px;
            margin-left: 370px;
            width: 50%;
            height: 890px;
            /* justify-content: center; */
            /* text-align: center; */

        }

        body {
            background: rgb(0, 14, 255);
            background: linear-gradient(73deg, rgba(0, 14, 255, 1) 0%, rgba(8, 0, 255, 1) 23%, rgba(139, 24, 106, 1) 47%, rgba(136, 16, 40, 1) 70%, rgba(135, 12, 12, 1) 100%, rgba(0, 9, 255, 1) 100%);
        }

        .col-25 {
            float: left;
            width: 25%;
            margin-top: 6px;
        }

        .col-75 {
            float: left;
            width: 75%;
            margin-top: 6px;
        }


        .row:after {
            content: "";
            display: table;
            clear: both;
        }

        .forms {
            width: 100%
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/animate.css">
    <script src="./js/bootstrap/wow.js"></script>
    <script src="js/wow.min.js"></script>
    <script>
        new WOW().init();



        wow = new WOW(
            {
                boxClass: 'wow',      // default
                animateClass: 'animated', // default
                offset: 0,          // default
                mobile: true,       // default
                live: true        // default
            }
        )
        wow.init();
    </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js" type="text/javascript"></script>
    <script type="text/javascript">
        var $FNameLNameRegEx = /^([a-zA-Z]{2,20})$/;
        var $LNameRegEx = /^([a-zA-Z ]{2,20})$/;
        var $EmailIdRegEx = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,8}\b$/i;

        $(document).ready(function () {


            $("#TxtFirstname").blur(function () {
                $("#TxtFirstnameValidate").empty();
                if ($(this).val().trim() == "" || $(this).val().trim() == null) {
                    $("#TxtFirstnameValidate").html("(*) Firstname required..!!");
                }
                else {
                    if (!$(this).val().trim().match($FNameLNameRegEx)) {
                        $("#TxtFirstnameValidate").html("Invalid firstname..!!");
                    }
                }
            });

            $("#TxtFirstname").keypress(function (e) {
                var ASCIIValue = e.which, Flag = false;

                $("#TxtFirstnameValidate").empty();

                ((ASCIIValue >= 65 && ASCIIValue <= 90) || (ASCIIValue >= 97 && ASCIIValue <= 121))
                    ? (Flag = true)
                    : ($("#TxtFirstnameValidate").html("Invalid input..!!"), Flag = false)

                return Flag;
            });

            $("#TxtLastname").keypress(function (e) {

                var ASCIIValue = e.which, Flag = false;

                $("#TxtLastnameValidate").empty();

                ((ASCIIValue >= 65 && ASCIIValue <= 90) || (ASCIIValue >= 97 && ASCIIValue <= 121))
                    ? (Flag = true)
                    : ($("#TxtLastnameValidate").html("Invalid input..!!"), Flag = false)

                return Flag;
            });
            $("#TxtLastname").blur(function () {
                $("#TxtLastnameValidate").empty();
                if ($(this).val().trim() == "" || $(this).val().trim() == null) {
                    $("#TxtLastnameValidate").html("(*) Lastname required..!!");
                }
                else {
                    if (!$(this).val().trim().match($FNameLNameRegEx)) {
                        $("#TxtLastnameValidate").html("Invalid lastname..!!");
                    }
                }
            });

            $("#TxtEmailid").blur(function () {
                $("#TxtEmailidValidate").empty();
                if ($(this).val().trim() == "" || $(this).val().trim() == null) {
                    $("#TxtEmailidValidate").html("(*) Email id required..!!");
                }
                else {
                    if (!$(this).val().trim().match($EmailIdRegEx)) {
                        $("#TxtEmailidValidate").html("Invalid emailid..!!");
                    }
                }
            });


            var TxtFirstnameFlag = false, TxtLastnameFlag = false, TxtEmailidFlag = false;
            $("#submits").click(function () {
                $("#TxtFirstnameValidate").empty();
                if ($("#TxtFirstname").val().trim() == "" || $("#TxtFirstname").val().trim() == null) {
                    $("#TxtFirstnameValidate").html("(*) Firstname required..!!");
                    TxtFirstnameFlag = false;
                }
                else {
                    if (!$("#TxtFirstname").val().trim().match($FNameLNameRegEx)) {
                        $("#TxtFirstnameValidate").html("Invalid firstname..!!");
                        TxtFirstnameFlag = false;
                    }
                    else {
                        TxtFirstnameFlag = true;
                    }
                }

                $("#TxtLastnameValidate").empty();
                if ($("#TxtLastname").val().trim() == "" || $("#TxtLastname").val().trim() == null) {
                    $("#TxtLastnameValidate").html("(*) Lastname required..!!");
                    TxtLastnameFlag = false;
                }
                else {
                    if (!$("#TxtLastname").val().trim().match($FNameLNameRegEx)) {
                        $("#TxtLastnameValidate").html("Invalid lastname..!!");
                        TxtLastnameFlag = false;
                    }
                    else {
                        TxtLastnameFlag = true;
                    }
                }
                $("#TxtEmailidValidate").empty();
                if ($("#TxtEmailid").val().trim() == "" || $("#TxtEmailid").val().trim() == null) {
                    $("#TxtEmailidValidate").html("(*) Email id required..!!");
                    TxtEmailidFlag = false;
                }
                else {
                    if (!$("#TxtEmailid").val().trim().match($EmailIdRegEx)) {
                        $("#TxtEmailidValidate").html("Invalid emailid..!!");
                        TxtEmailidFlag = false;
                    }
                    else {
                        TxtEmailidFlag = true;
                    }
                }

                if (TxtFirstnameFlag == true && TxtLastnameFlag == true && TxtEmailidFlag == true) {
                    alert("Form Submitted Successfully..!!");
                }
                else {
                    alert("Invalid Form Inputs..!!");
                }
            });
        });
    </script>
</head>

<body>
    <form action="#" method="POST">
        <!-- <h2 class="haed2"><i class="fa fa-file">By Elegance Pvt.Ltd.</i></h2> -->
        <!-- <h4 class="head4">Feed Back Form</h4> -->
        <div class="container wow bounceInUp">

            <h4 class="head4">Feedback Form</h4>
            <div class="row">
                <div class="col-50">
                    <label for="TxtFirstname">First Name</label>
                </div>
                <div class="col-75 wow bounceInUp" data-wow-duration="3s">
                    <input type="text" id="TxtFirstname" name="firstname" placeholder="Your name..">
                    <small class="text-danger" id="TxtFirstnameValidate"></small>
                </div>
                <!-- <small class="text-danger" id="TxtFirstnameValidate"></small> -->
            </div>
            <br>
            <div class="row">
                <div class="col-50">
                    <label for="TxtLastname">Last Name</label>
                </div>
                <div class="col-75  wow bounceInUp" data-wow-duration="3s">
                    <input type="text" id="TxtLastname" name="lastname" placeholder="Your last name..">
                    <small class="text-danger" id="TxtLastnameValidate"></small>
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-50">
                    <label for="TxtEmailid">Mail Id</label>
                </div>
                <div class="col-75  wow bounceInUp" data-wow-duration="3s">
                    <input type="email" id="TxtEmailid" name="mailid" placeholder="Your mail id..">
                    <small class="text-danger" id="TxtEmailidValidate"></small>
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-5">
                    <label for="City">City</label>
                </div>
                <div class="col-75  wow bounceInUp" data-wow-duration="3s">
                    <select id="City" name="City">
                        <option value="none">Select City</option>
                        <option value="Ahmedabad">Ahmedabad</option>
                        <option value="Mumbai">Mumbai</option>
                        <option value="Delhi">Delhi</option>
                        <option value="Banglore">Banglore</option>
                        <option value="Hydrabad">Hydrabad</option>
                    </select>
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-50">
                    <label for="feedback">Feedback</label>
                </div>
                <div class="col-75  wow bounceInUp" data-wow-duration="3s">
                    <textarea id="subject" name="subject" placeholder="Write something.."
                        style="height:200px"></textarea>
                </div>
            </div>
            <br>
            <div class="row  wow bounceInUp" data-wow-duration="3s">
                <input type="submit" value="Submit" id="submits">
            </div>
        </div>
    </form>
</body>

</html>